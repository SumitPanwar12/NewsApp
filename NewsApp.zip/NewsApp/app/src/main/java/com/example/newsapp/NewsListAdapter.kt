package com.example.newsapp

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView


class NewsListAdapter(private val items: ArrayList<String>) : RecyclerView.Adapter<NewsViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_news, parent,false)
        return NewsViewHolder(view)
    }

    override fun getItemCount(): Int {

        return items.count()
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onBindViewHolder(p0: NewsViewHolder, p1: Int) {
        val currentItem = items[p1]
        p0.titleView.text = currentItem
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}



class NewsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
            val titleView: TextView = itemView.findViewById(R.id.title)
}